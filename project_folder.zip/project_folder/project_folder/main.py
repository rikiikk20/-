# main.py
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Главное меню игры "Давай поиграем"
Программа для выбора и запуска различных игр
"""

import os
import sys

# Добавляем папку games в путь Python
sys.path.append(os.path.join(os.path.dirname(__file__), 'games'))

def clear_screen():
    """Очищает экран консоли"""
    os.system('cls' if os.name == 'nt' else 'clear')

def show_welcome():
    """Показывает приветственное сообщение"""
    clear_screen()
    print("\n" + "🎮" * 30)
    print(" " * 20 + "ДОБРО ПОЖАЛОВАТЬ!")
    print(" " * 15 + "В ИГРОВОЙ КОМПЛЕКС")
    print(" " * 10 + "\"ДАВАЙ ПОИГРАЕМ!\"")
    print("🎮" * 30)
    
    print("\n" + "📋" * 30)
    print(" В этом комплексе вы найдете 4 увлекательные игры:")
    print("📋" * 30)
    
    print("\n1. 🎭 ВИСЕЛИЦА")
    print("   Угадайте слово по буквам, пока человечек не повешен")
    
    print("\n2. ❌⭕ КРЕСТИКИ-НОЛИКИ")
    print("   Классическая игра против компьютера или друга")
    
    print("\n3. 🔢 УГАДАЙ ЧИСЛО")
    print("   Попробуйте угадать число за минимальное количество попыток")
    
    print("\n4. 🦁 УГАДАЙ ЖИВОТНОЕ")
    print("   Отгадайте животное по загадке")
    
    print("\n" + "=" * 60)

def show_menu():
    """Показывает главное меню"""
    print("\n" + "═" * 60)
    print(" " * 20 + "🎮 ГЛАВНОЕ МЕНЮ 🎮")
    print("═" * 60)
    
    print("\n" + " " * 18 + "ВЫБЕРИТЕ ИГРУ:")
    print("-" * 60)
    print()
    print(" " * 10 + "1. 🎭  Виселица")
    print(" " * 10 + "2. ❌⭕  Крестики-нолики")
    print(" " * 10 + "3. 🔢  Угадай число")
    print(" " * 10 + "4. 🦁  Угадай животное")
    print(" " * 10 + "5. 🚪  Выход")
    print()
    print("-" * 60)

def main():
    """Главная функция программы"""
    show_welcome()
    
    while True:
        show_menu()
        
        choice = input("\nВаш выбор (1-5): ").strip()
        
        if choice == '1':
            # Виселица
            clear_screen()
            try:
                from games.hangman import play_hangman
                play_hangman()
            except ImportError:
                print("Ошибка: Не удалось загрузить игру 'Виселица'")
                input("Нажмите Enter чтобы продолжить...")
                
        elif choice == '2':
            # Крестики-нолики
            clear_screen()
            try:
                from games.tictactoe import play_tictactoe
                play_tictactoe()
            except ImportError:
                print("Ошибка: Не удалось загрузить игру 'Крестики-нолики'")
                input("Нажмите Enter чтобы продолжить...")
                
        elif choice == '3':
            # Угадай число
            clear_screen()
            try:
                from games.guess_number import play_guess_number
                play_guess_number()
            except ImportError:
                print("Ошибка: Не удалось загрузить игру 'Угадай число'")
                input("Нажмите Enter чтобы продолжить...")
                
        elif choice == '4':
            # Угадай животное
            clear_screen()
            try:
                from games.guess_animal import play_guess_animal
                play_guess_animal()
            except ImportError:
                print("Ошибка: Не удалось загрузить игру 'Угадай животное'")
                input("Нажмите Enter чтобы продолжить...")
                
        elif choice == '5':
            # Выход
            clear_screen()
            print("\n" + "👋" * 20)
            print(" " * 10 + "Спасибо за игру! До встречи!")
            print("👋" * 20)
            print("\n" + "=" * 60)
            break
            
        else:
            print("\n❌ Неверный выбор! Пожалуйста, введите число от 1 до 5")
            input("Нажмите Enter чтобы продолжить...")
            clear_screen()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nИгра прервана пользователем.")
    except Exception as e:
        print(f"\nПроизошла непредвиденная ошибка: {e}")
        input("Нажмите Enter для выхода...")