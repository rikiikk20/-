import random
import json
import os
from datetime import datetime

# ДАННЫЕ ИГРЫ 

# Расширила словарь с животными - добавила категории и факты для образовательной ценности
animals = {
    "кот": {
        "загадки": [
            "Мягкие лапки, а в лапках царапки. Молоко пьёт, песенки поёт.",
            "Мурлычет, когда его гладят, умывается лапкой."
        ],
        "категория": "домашние",
        "факт": "Коты спят до 16 часов в день!",
        "сложность": 1
    },
    "собака": {
        "загадки": [
            "Гавкает, хвостом виляет, дом охраняет.",
            "Верный друг человека, косточки любит грызть."
        ],
        "категория": "домашние",
        "факт": "Собаки могут различать до 250 слов и жестов.",
        "сложность": 1
    },
    "слон": {
        "загадки": [
            "Серый великан, с длинным носом-шлангом.",
            "Самое большое сухопутное животное с хоботом."
        ],
        "категория": "дикие",
        "факт": "Слоны могут узнавать себя в зеркале!",
        "сложность": 2
    },
    "заяц": {
        "загадки": [
            "Длинные ушки, быстрые ножки, морковку любит и капусту.",
            "Летом серый, зимой белый, прыгает ловко."
        ],
        "категория": "дикие",
        "факт": "Зайцы могут развивать скорость до 70 км/ч!",
        "сложность": 1
    },
    "лиса": {
        "загадки": [
            "Хитрая плутовка, рыжая головка, в лесу живёт, кур крадёт.",
            "Рыжий мех, пушистый хвост, в сказках всех обманывает."
        ],
        "категория": "дикие",
        "факт": "Лисы используют магнитное поле Земли для охоты.",
        "сложность": 2
    },
    "медведь": {
        "загадки": [
            "Большой, косолапый, мёд любит, зимой спит.",
            "Бурый лесной житель, в берлоге зимует."
        ],
        "категория": "дикие",
        "факт": "Медведи могут бегать со скоростью до 50 км/ч!",
        "сложность": 2
    },
    "корова": {
        "загадки": [
            "Мычит, траву жуёт, молоко даёт.",
            "На лугу пасётся, молоком делится."
        ],
        "категория": "домашние",
        "факт": "Коровы имеют лучших друзей и проводят с ними много времени.",
        "сложность": 1
    },
    "лошадь": {
        "загадки": [
            "Быстро скачет, грива развевается, иго-го кричит.",
            "На ней можно ездить верхом, копытами стучит."
        ],
        "категория": "домашние",
        "факт": "Лошади могут спать стоя!",
        "сложность": 1
    },
    "пингвин": {
        "загадки": [
            "В чёрном фраке ходит важно, живёт на льду отважно.",
            "Не летает, но ныряет, в холоде обитает."
        ],
        "категория": "дикие",
        "факт": "Некоторые пингвины ныряют на глубину до 500 метров!",
        "сложность": 3
    },
    "жираф": {
        "загадки": [
            "Длинная шея, пятнистая шкура, листья с деревьев срывает.",
            "Самое высокое животное, до неба достаёт."
        ],
        "категория": "дикие",
        "факт": "Шея жирафа содержит столько же позвонков, сколько у человека - всего 7!",
        "сложность": 2
    }
}

# Добавила три уровня сложности - чтобы игра подходила и детям, и взрослым
DIFFICULTY_SETTINGS = {
    "легкий": {
        "попытки": 5,
        "показывать_подсказки": True,
        "показывать_категорию": True,
        "фильтр_сложности": [1],
        "описание": "Для начинающих - простые животные, много попыток"
    },
    "средний": {
        "попытки": 3,
        "показывать_подсказки": True,
        "показывать_категорию": False,
        "фильтр_сложности": [1, 2],
        "описание": "Стандартный режим - умеренная сложность"
    },
    "сложный": {
        "попытки": 2,
        "показывать_подсказки": False,
        "показывать_категорию": False,
        "фильтр_сложности": [1, 2, 3],
        "описание": "Для экспертов - мало попыток, все животные"
    }
}

# Создала систему достижений - чтобы было интереснее играть много раз
ACHIEVEMENTS = {
    "первая_победа": {"название": "🏆 Первая победа", "описание": "Угадала первое животное", "получено": False},
    "серия_3": {"название": "🔥 Горячая серия", "описание": "Угадала 3 животных подряд", "получено": False},
    "серия_5": {"название": "⭐ Непобедимая", "описание": "Угадала 5 животных подряд", "получено": False},
    "знаток": {"название": "📚 Знаток животных", "описание": "Угадала всех животных хотя бы раз", "получено": False},
    "с_первой_попытки": {"название": "🎯 Снайпер", "описание": "Угадала с первой попытки 3 раза", "получено": False},
    "марафон": {"название": "🏃 Марафонец", "описание": "Сыграла 10 раундов за одну сессию", "получено": False}
}

player_stats = {
    "всего_игр": 0,
    "угадано": 0,
    "не_угадано": 0,
    "текущая_серия": 0,
    "лучшая_серия": 0,
    "угаданные_животные": set(),
    "попыток_с_первого_раза": 0,
    "история_игр": []
}

# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ

def load_stats():
    """Загрузила статистику из файла - чтобы прогресс сохранялся между запусками"""
    global player_stats, ACHIEVEMENTS
    try:
        if os.path.exists('animal_game_stats.json'):
            with open('animal_game_stats.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
                player_stats.update(data.get('stats', {}))
                player_stats['угаданные_животные'] = set(player_stats.get('угаданные_животные', []))
                
                saved_achievements = data.get('achievements', {})
                for key in ACHIEVEMENTS:
                    if key in saved_achievements:
                        ACHIEVEMENTS[key]['получено'] = saved_achievements[key].get('получено', False)
    except Exception as e:
        print(f"⚠️ Не удалось загрузить статистику: {e}")

def save_stats():
    """Сохранила статистику в файл"""
    try:
        data = {
            'stats': {
                **player_stats,
                'угаданные_животные': list(player_stats['угаданные_животные'])
            },
            'achievements': ACHIEVEMENTS,
            'last_updated': datetime.now().isoformat()
        }
        with open('animal_game_stats.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"⚠️ Не удалось сохранить статистику: {e}")

def check_achievements():
    """Проверила, получены ли новые достижения"""
    new_achievements = []
    
    if player_stats['угадано'] >= 1 and not ACHIEVEMENTS['первая_победа']['получено']:
        ACHIEVEMENTS['первая_победа']['получено'] = True
        new_achievements.append('первая_победа')
    
    if player_stats['текущая_серия'] >= 3 and not ACHIEVEMENTS['серия_3']['получено']:
        ACHIEVEMENTS['серия_3']['получено'] = True
        new_achievements.append('серия_3')
    
    if player_stats['текущая_серия'] >= 5 and not ACHIEVEMENTS['серия_5']['получено']:
        ACHIEVEMENTS['серия_5']['получено'] = True
        new_achievements.append('серия_5')
    
    if len(player_stats['угаданные_животные']) >= len(animals) and not ACHIEVEMENTS['знаток']['получено']:
        ACHIEVEMENTS['знаток']['получено'] = True
        new_achievements.append('знаток')
    
    if player_stats['попыток_с_первого_раза'] >= 3 and not ACHIEVEMENTS['с_первой_попытки']['получено']:
        ACHIEVEMENTS['с_первой_попытки']['получено'] = True
        new_achievements.append('с_первой_попытки')
    
    if player_stats['всего_игр'] >= 10 and not ACHIEVEMENTS['марафон']['получено']:
        ACHIEVEMENTS['марафон']['получено'] = True
        new_achievements.append('марафон')
    
    if new_achievements:
        print("\n" + "🎊" * 20)
        print("   НОВОЕ ДОСТИЖЕНИЕ РАЗБЛОКИРОВАНО!")
        for ach_key in new_achievements:
            ach = ACHIEVEMENTS[ach_key]
            print(f"\n   {ach['название']}")
            print(f"   {ach['описание']}")
        print("\n" + "🎊" * 20)
        input("\nНажмите Enter чтобы продолжить...")

def show_statistics():
    """Показала детальную статистику игрока"""
    print("\n" + "=" * 60)
    print(" " * 20 + "📊 СТАТИСТИКА ИГРОКА")
    print("=" * 60)
    
    print(f"\n📈 Всего игр сыграно: {player_stats['всего_игр']}")
    print(f"✅ Угадано: {player_stats['угадано']}")
    print(f"❌ Не угадано: {player_stats['не_угадано']}")
    
    if player_stats['всего_игр'] > 0:
        win_rate = (player_stats['угадано'] / player_stats['всего_игр']) * 100
        print(f"🎯 Процент успеха: {win_rate:.1f}%")
    
    print(f"\n🔥 Текущая серия: {player_stats['текущая_серия']}")
    print(f"⭐ Лучшая серия: {player_stats['лучшая_серия']}")
    print(f"🎯 Угадано с первой попытки: {player_stats['попыток_с_первого_раза']}")
    
    print(f"\n🦁 Угадано уникальных животных: {len(player_stats['угаданные_животные'])}/{len(animals)}")
    
    print("\n" + "─" * 60)
    print("🏆 ДОСТИЖЕНИЯ:")
    obtained = sum(1 for a in ACHIEVEMENTS.values() if a['получено'])
    print(f"Получено: {obtained}/{len(ACHIEVEMENTS)}")
    print()
    
    for ach in ACHIEVEMENTS.values():
        status = "✓" if ach['получено'] else "✗"
        print(f"  {status} {ach['название']} - {ach['описание']}")
    
    print("=" * 60)

def choose_difficulty():
    """Позволила игроку выбрать уровень сложности"""
    print("\n" + "=" * 60)
    print(" " * 20 + "⚙️ ВЫБОР СЛОЖНОСТИ")
    print("=" * 60)
    print()
    
    for i, (key, settings) in enumerate(DIFFICULTY_SETTINGS.items(), 1):
        print(f"{i}. {key.upper()}")
        print(f"   {settings['описание']}")
        print(f"   Попыток: {settings['попытки']}")
        print()
    
    while True:
        choice = input("Выберите уровень сложности (1-3): ").strip()
        if choice in ['1', '2', '3']:
            difficulties = list(DIFFICULTY_SETTINGS.keys())
            return difficulties[int(choice) - 1]
        print("❌ Пожалуйста, введите 1, 2 или 3")

def get_hint(animal_name, difficulty_settings):
    """Дала подсказку игроку"""
    if not difficulty_settings['показывать_подсказки']:
        return None
    
    animal_data = animals[animal_name]
    hints = []
    
    if difficulty_settings['показывать_категорию']:
        hints.append(f"Категория: {animal_data['категория']}")
    
    hints.append(f"Количество букв: {len(animal_name)}")
    hints.append(f"Первая буква: {animal_name[0].upper()}")
    
    return hints

# ГЛАВНАЯ ФУНКЦИЯ ИГРЫ 

def play_animal_game():
    """Главная функция игры"""

    load_stats()

    print("=" * 60)
    print("   Добро пожаловать в игру 'Угадай животное' v2.0!")
    print("=" * 60)

    while True:
        print("\n📋 МЕНЮ:")
        print("1. Начать игру")
        print("2. Посмотреть статистику")
        print("3. Посмотреть достижения")
        print("4. Выход")

        menu_choice = input("\nВыберите действие: ").strip()

        if menu_choice == "2":
            show_statistics()
            input("\nНажмите Enter для продолжения...")
            continue

        if menu_choice == "3":
            print("\n🏆 ДОСТИЖЕНИЯ:")
            for ach in ACHIEVEMENTS.values():
                status = "✓" if ach['получено'] else "✗"
                print(f"  {status} {ach['название']} - {ach['описание']}")
            input("\nНажмите Enter для продолжения...")
            continue

        if menu_choice == "4":
            save_stats()
            print("\nСпасибо за игру! Ваш прогресс сохранён.")
            return

        if menu_choice != "1":
            print("❌ Неверный выбор")
            continue

        # --- старт игровой сессии ---
        difficulty = choose_difficulty()
        settings = DIFFICULTY_SETTINGS[difficulty]

        print(f"\n✅ Выбран уровень: {difficulty.upper()}")
        print(f"У вас будет {settings['попытки']} попыток на каждое животное")

        while True:
            try:
                rounds = int(input("\nСколько раундов вы хотите сыграть? "))
                if rounds > 0:
                    break
                else:
                    print("Пожалуйста, введите положительное число.")
            except ValueError:
                print("Пожалуйста, введите корректное число.")

        available_animals = {
            name: data for name, data in animals.items()
            if data['сложность'] in settings['фильтр_сложности']
        }

        if not available_animals:
            print("⚠️ Нет доступных животных для выбранной сложности.")
            continue

        print(f"\n🎮 Начинаем игру! Доступно животных: {len(available_animals)}")
        print("=" * 60)

        session_history_start = len(player_stats['история_игр'])

        for round_num in range(1, rounds + 1):
            print(f"\n{'='*60}")
            print(f"   РАУНД {round_num} из {rounds}")
            print(f"{'='*60}")

            animal_name = random.choice(list(available_animals.keys()))
            animal_data = available_animals[animal_name]
            riddle = random.choice(animal_data['загадки'])

            print(f"\n🎯 Загадка: {riddle}")

            attempts = 0
            max_attempts = settings['попытки']
            round_won = False
            hints_used = 0

            while attempts < max_attempts:
                attempts += 1
                print(f"\n📝 Попытка {attempts}/{max_attempts}")

                if attempts > 1 and attempts < max_attempts and settings['показывать_подсказки']:
                    want_hint = input("Хотите подсказку? (да/нет): ").strip().lower()
                    if want_hint in ['да', 'д', 'yes', 'y']:
                        hints = get_hint(animal_name, settings)
                        if hints and hints_used < len(hints):
                            print(f"💡 Подсказка: {hints[hints_used]}")
                            hints_used += 1

                guess = input("Ваш ответ: ").strip().lower()

                if guess == animal_name:
                    print("\n" + "🎉" * 20)
                    print(f"   ✓ ПРАВИЛЬНО! Это {animal_name.upper()}!")
                    print(f"   Угадано с попытки {attempts}!")
                    print("🎉" * 20)

                    print(f"\n📚 Интересный факт: {animal_data['факт']}")

                    player_stats['всего_игр'] += 1
                    player_stats['угадано'] += 1
                    player_stats['текущая_серия'] += 1
                    player_stats['угаданные_животные'].add(animal_name)

                    if attempts == 1:
                        player_stats['попыток_с_первого_раза'] += 1

                    if player_stats['текущая_серия'] > player_stats['лучшая_серия']:
                        player_stats['лучшая_серия'] = player_stats['текущая_серия']

                    player_stats['история_игр'].append({
                        'животное': animal_name,
                        'попыток': attempts,
                        'успех': True,
                        'дата': datetime.now().isoformat()
                    })

                    round_won = True
                    check_achievements()
                    break
                else:
                    if attempts < max_attempts:
                        print("   ✗ Неправильно. Попробуйте ещё раз.")
                    else:
                        print("\n   ✗ К сожалению, попытки закончились.")
                        print(f"   Правильный ответ: {animal_name.upper()}")
                        print(f"\n📚 Интересный факт: {animal_data['факт']}")

            if not round_won:
                player_stats['всего_игр'] += 1
                player_stats['не_угадано'] += 1
                player_stats['текущая_серия'] = 0
                player_stats['история_игр'].append({
                    'животное': animal_name,
                    'попыток': max_attempts,
                    'успех': False,
                    'дата': datetime.now().isoformat()
                })

            save_stats()

            if round_num < rounds:
                input("\nНажмите Enter для следующего раунда...")

        print("\n" + "=" * 60)
        print(" " * 20 + "🏁 ИГРА ОКОНЧЕНА!")
        print("=" * 60)

        session_games = player_stats['история_игр'][session_history_start:]
        session_wins = sum(1 for game in session_games if game['успех'])

        print("\n📊 Результаты этой сессии:")
        print(f"   Сыграно раундов: {rounds}")
        print(f"   Угадано: {session_wins}")
        print(f"   Процент успеха: {(session_wins/rounds)*100:.1f}%")

        print(f"\n🔥 Текущая серия: {player_stats['текущая_серия']}")
        print(f"⭐ Лучшая серия за всё время: {player_stats['лучшая_серия']}")
        print("\n" + "=" * 60)

        check_achievements()
        save_stats()

        input("\nНажмите Enter, чтобы вернуться в меню...")

    
    while True:
        again = input("\nХотите сыграть ещё раз? (да/нет): ").strip().lower()
        if again in ["да", "yes", "д", "y"]:
            print()
            play_animal_game()
            break
        elif again in ["нет", "no", "н", "n"]:
            print("\nСпасибо за игру! Ваш прогресс сохранён.")
            print("Возвращаемся в главное меню...")
            break
        else:
            print("Пожалуйста, введите 'да' или 'нет'.")

if __name__ == "__main__":
    play_animal_game()
